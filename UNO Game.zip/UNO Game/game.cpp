#include <iostream>
#include <windows.h>
#include <cstdlib>
#include <fstream>  
#include <ctime>
#include<string>
using namespace std;

// Constants
const int max_color = 8;
const int max_type = 15;
const int total_cards = 108;
const int BLACK = 0;
const int BLUE = 1;
const int GREEN = 2;
const int YELLOW = 6;
const int RED = 4;
const int WHITE = 7;
int currentPlayer = 1;
int nextPlayer = 2;
int deck[10][15] = {};
int player1[108];
int player2[108];
int wildCard_color = -1;                
int player1Score = 0;
int player2Score = 0;      
int totalTurns = 0; 

// Function Prototypes
void setColor(int textColor, int bgColor);
void clearScreen();
void mainMenu();
void gameInstructions();
void playUNO();
void initializeDeck(int deck[10][15]);
void shuffleDeck(int deck[10][15]);
void dealCards(int [][27]);
void playGame();
int printCards(int playerCards[108]);
int printRemainingDeck();
void printBoard(int topCard);
int printTopCard(int cardValue, int color);
bool isValidPlay(int playerCard, int topCard);
bool checkWinCondition(int player[]);
void playTurn(int playerCards[108], int &topCard, ofstream &gameLog);
bool isPlayerWinner(int playerCards[108]);
void saveLoadGameResult(int, int );
void handleSpecialCard(int specialCardType, int &topCard);
int drawFromDeck(int playerCards[108], int cardsToDraw);
void removePlayedCard(int playerCards[108], int cardIndex);

		// Main Function

int main() {

   	mainMenu();
	for (int i=0; i<108; i++){
	player1[i] = -1;
	player2[i] = -1;
	
}
    initializeDeck(deck);
    shuffleDeck(deck);
	playGame() ;
    return 0;
}


void clearScreen() {
    system("CLS");
}


void setColor(int textColor, int bgColor) {
  
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, (bgColor << 4) | textColor);
}

// Function to play the UNO game
void playUNO() {
    clearScreen();
    setColor(RED, BLACK);
    cout << "Starting UNO Game..." << endl;
    setColor(WHITE, BLACK);


    cout << "Press any button to continue. " <<endl;
    cout << "            OR             " <<endl;
    cout << "Press 'E' to exit to the main menu at any time." << endl;
    char input;
    cin >> input;
        clearScreen();

    if (tolower(input) == 'e') {
        clearScreen();
        cout << "Are you sure you want to return to the main menu? (Y/N): ";
        char confirm;
        cin >> confirm;
        if (tolower(confirm) == 'y') {
            mainMenu();
        } else {
            playUNO();
        }
    }
}


// Function to display the main menu
void mainMenu() {
    while (true) {
        clearScreen();
        setColor(WHITE, BLACK);

        cout << "=====================================" << endl;
        setColor(RED, BLACK);
        cout << "      WELCOME TO THE UNO GAME!       " << endl;
        setColor(WHITE, BLACK);
        cout << "=====================================" << endl;
        cout << "1. Play Game" << endl;
        cout << "2. Instructions" << endl;
        cout << "3. Exit" << endl;
        cout << "=====================================" << endl;

        setColor(YELLOW, BLACK);
        cout << "Enter your choice (1-3): ";
        setColor(WHITE, BLACK);
        int choice;
        cin >> choice;

       if (choice == 1) {
    playUNO();
    break;
} 
else if (choice == 2) {
    gameInstructions();
} else if (choice == 3) {
    clearScreen();
    cout << "Are you sure you want to exit? (Y/N): ";
    char confirmExit;
    cin >> confirmExit;
    if (tolower(confirmExit) == 'y') {
        cout << "Thank you for playing! Goodbye!" << endl;
        exit(0);
    }
} else {
    cout << "Invalid choice! Please select a valid option." << endl;
    system("pause");
}

    }
}

// Function to display game instructions
void gameInstructions() {
    clearScreen();
    setColor(BLUE, BLACK);

    cout << "================ GAME INSTRUCTIONS ================" << endl;
    cout << "1. UNO is a card game where players take turns." << endl;
    cout << "2. Match the top card by color or number to play a card." << endl;
    cout << "3. Special cards include Reverse, Skip, Draw 2, Wild, and Wild Draw 4." << endl;
    cout << "4. The first player to get rid of all their cards wins!" << endl;
    cout << "5. At any time, you can press 'E' to exit the game." << endl;
    cout << "===================================================" << endl;

    setColor(WHITE, BLACK);
    system("pause");
}


// Initialization

void initializeDeck(int deck[10][15]) {
    
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 13; j++) {
            deck[i][j] = j; 
        }
        deck[i][13] = -1;
        deck[i][14] = -1;
    }

    // Duplicates
    for (int i = 4; i < 8; i++) {
    	deck [i] [0] = -1;
        for (int j = 1; j < 13; j++) {
            deck[i][j] = j ;  // Cards 1 to 12
        }
        deck[i][13] = -1;
        deck[i][14] = -1;
    }

    for (int i = 8; i < 9; i++) {
	
        for (int j = 0; j < 14; j++) {
            deck[i][j] = -1;  
        }

        deck[i][11] = 13;
        deck [i][12] = 13;
        deck[i][13] = 13;
        deck[i][14] = 13;
    }

    for (int i = 9; i < 10; i++) {
        for (int j = 0; j < 14; j++) {
            deck[i][j] = -1;  // No cards
        }
		        deck[i][11] = 14;
        deck [i][12] = 14;
        deck[i][13] = 14;
        deck[i][14] = 14;
    }
}

// Shuffling the deck

void shuffleDeck(int deck[10][15]) {
    srand(time(0)); 

    int filteredDeck[108];  
    int count = 0;
    for (int row = 0; row < 10; ++row) {
        for (int col = 0; col < 15; ++col) {
            if (deck[row][col] != -1) {
                filteredDeck[count] = deck[row][col];
                count++;
            }
        }
    }

    int newDeck[4][27];  
    int current = 0;

    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 27; ++j) {
            newDeck[i][j] = filteredDeck[current];
            current++;
        }
    }

    int cardPattern[27];  
    int index = 0;
    cardPattern[index++] = 0;
    for (int i = 1; i <= 12; ++i) {
        cardPattern[index++] = i;
        cardPattern[index++] = i;
    }
    cardPattern[index++] = 13;
    cardPattern[index++] = 14;
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 27; ++j) {
            newDeck[i][j] = cardPattern[j];
        }
    }

// First digit will represent the color and last two digits will represent the value
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 27; ++j) {
            if (i == 0) {
                newDeck[i][j] += 100;
            } else if (i == 1) {
                newDeck[i][j] += 200;
            } else if (i == 2) {
                newDeck[i][j] += 300;
            } else if (i == 3) {
                newDeck[i][j] += 400;
            }
        }
    }

    // Shuffle the deck
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 27; ++j) {
            int randomRow = rand() % 4;
            int randomCol = rand() % 27;

            int temp = newDeck[i][j];
            newDeck[i][j] = newDeck[randomRow][randomCol];
            newDeck[randomRow][randomCol] = temp;
        }
    }

    dealCards(newDeck);
}

// Dealing with Cards
void dealCards(int newDeck[4][27]) {
    int currentCard = 0; 

    // Deal cards to player 1
    for (int i = 0; i < 7; i++) {
        int row = currentCard / 27;
        int col = currentCard % 27;
        player1[i] = newDeck[row][col];
        newDeck[row][col] = -1;  
        currentCard++;
    }

 
    for (int i = 0; i < 7; i++) {
        int row = currentCard / 27;
        int col = currentCard % 27;
        player2[i] = newDeck[row][col];
        newDeck[row][col] = -1; 
        currentCard++;
    }

    int remainingIndex = 0;

    for (int row = 0; row < 4; row++) {
        for (int col = 0; col < 27; col++) {
            if (newDeck[row][col] != -1) {
                deck[remainingIndex / 15][remainingIndex % 15] = newDeck[row][col];
                remainingIndex++;
            }
        }
    }

    // Mark any unused spots in the deck as -1
    for (int i = remainingIndex; i < 150; i++) {
        deck[i / 15][i % 15] = -1;
    }
}

// Filing 
void saveGameResult(int winner, int player1Score, int player2Score) {
    ofstream resultFile("game_result.txt", ios::out);
    if (resultFile.is_open()) {
        resultFile << "Game over!" << endl;
        resultFile << "Total Turns: " << totalTurns << endl;
        resultFile << "Player 1 Score: " << player1Score << endl;
        resultFile << "Player 2 Score: " << player2Score << endl;
        resultFile << "Winner: Player " << winner << endl;
        resultFile.close();
    } else {
        cout << "Error saving the result to the file." << endl;
    }
}

int GetScore(int playerCards[108]) {
    int score = 0;

    for (int i = 0; i < 108; i++) {
        if (playerCards[i] == -1) {
            // Skip empty card slots
            continue;
        }

        int cardValue = playerCards[i] % 100; // Get the last two digits to determine card type

        if (cardValue >= 0 && cardValue <= 9) {
            // Number cards (0–9)
            score += cardValue;
        } else if (cardValue >= 10 && cardValue <= 12) {
            // Special cards (e.g., Skip, Reverse, Draw Two)
            score += 20;
        } else if (cardValue == 13 || cardValue == 14) {
            // Wild cards
            score += 50;
        }
    }

    return score;
}

void playGame() {
    int topCard = printRemainingDeck();  
    int player1Score = 0, player2Score = 0;
    int player1WinCount = 0, player2WinCount = 0;

    // Open the file to log game history (new file each time)
    ofstream gameLog("game_log.txt", ios::trunc);  
    if (!gameLog) {
        cerr << "Error opening file for logging!" << endl;
        return;
    }

    gameLog << "Game Start!" << endl;

    while (true) {
        totalTurns++;  // Increment turn count
        printBoard(topCard);  

        if (currentPlayer == 1) {
            gameLog << "Turn " << totalTurns << ": Player 1's turn." << endl;
            playTurn(player1, topCard, gameLog);  
        } else if (currentPlayer == 2) {
            gameLog << "Turn " << totalTurns << ": Player 2's turn." << endl;
            playTurn(player2, topCard, gameLog);  
        }

        cout << endl << endl;
        cout << "-----------Press Enter to continue--------------";
        cin.ignore();
        cin.get();
        clearScreen();

        if (isPlayerWinner(player1)) {
            player1WinCount++;
            player1Score = GetScore(player1);  // Assuming GetScore is defined to calculate score
            saveGameResult(1, player1Score, player2Score);
            gameLog << "Player 1 has won the game!" << endl;
            break;
        }

        if (isPlayerWinner(player2)) {
            player2WinCount++;
            player2Score = GetScore(player2);  // Assuming GetScore is defined to calculate score
            saveGameResult(2, player1Score, player2Score);
            gameLog << "Player 2 has won the game!" << endl;
            break;
        }
    }

    gameLog.close();  // Close the log file after game ends
}	
bool isPlayerWinner(int playerCards[108]) {
    for (int i = 0; i < 108; i++) {
        if (playerCards[i] != -1) {  
            return false;
        }
    }
    return true; 
}


// Play Turn
void playTurn(int playerCards[108], int &topCard, ofstream &gameLog) {
    int choice;
    bool turnComplete = false;

    while (!turnComplete) {
        cout << "Player " << currentPlayer << "'s Turn!" << endl;
        cout << "Do you want to (1) Play a card or (2) Draw a card? ";
        cin >> choice;

        if (choice == 1) {
            int cardIndex;
            cout << "Enter the card number: ";
            cin >> cardIndex;
            cardIndex--;  // Adjust for 0-based index

            if (cardIndex < 0 || cardIndex >= 108 || playerCards[cardIndex] == -1) {
                cout << "Invalid card. Try again." << endl;
                continue;
            }

            int selectedCard = playerCards[cardIndex];
            if (isValidPlay(selectedCard, topCard)) {
                topCard = selectedCard;
                removePlayedCard(playerCards, cardIndex);  // Will remove the card from player hand
                gameLog << "Player " << currentPlayer << " played card: " << selectedCard << endl;

                // Handle special cards
                if (selectedCard % 100 >= 10) {
                    handleSpecialCard(selectedCard % 100, topCard);  // Go to handle Special Card Function
                } else if (selectedCard % 100 < 10) {
                    currentPlayer = (currentPlayer == 1) ? 2 : 1;
                }

                turnComplete = true;
            } else {
                cout << "Invalid move! Card doesn't match the top card. Try again." << endl;
            }
        } else if (choice == 2) {
            int cardsDrawn = drawFromDeck(playerCards, 1);
            if (cardsDrawn > 0) {
                cout << "You drew a card!" << endl;
                gameLog << "Player " << currentPlayer << " drew a card." << endl;
                turnComplete = true;
                currentPlayer = (currentPlayer == 1) ? 2 : 1;
            } else {
                cout << "Deck is empty! No cards to draw." << endl;
            }
        } else {
            cout << "Invalid choice. Please select 1 or 2." << endl;
        }
    }
}

int printRemainingDeck() {
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 15; j++) {
        	
            if (deck[i][j] != -1 && deck[i][j] % 100 != 13 && deck[i][j] % 100 != 14) {
                int topCard = deck[i][j];
                
                // Mark the card as used
                deck[i][j] = -1;
                
                return topCard; // Return the valid top card
            }
        }
    }

    cout << "No cards remaining in the deck!" << endl;
    return -1;
}


int assign_color (int color){
	int bgColor;
 			switch (color) {
                case 1: bgColor = 4; break;   // Red
                case 2: bgColor = 1; break;  // Blue
                case 3: bgColor = 2; break; // Green
                case 4: bgColor = 6; break; // Yellow
                default: bgColor = 7; break; // Default white for other cases
            }
            return bgColor;
}

// Print Board Function

void printBoard(int topCard) {
    cout << endl;
    cout << "---------- Current Game State ----------" << endl;
    cout << endl;

    
    if (currentPlayer == 1) {
        cout << "Player 1's Cards:" << endl;
        setColor(WHITE, BLACK);
        printCards(player1);
    } else {
        cout << "Player 1's Cards: [Hidden]" << endl;
    }
    
    cout << endl;

    
    if (currentPlayer == 2) {
        cout << "Player 2's Cards:" << endl <<endl;
        setColor(WHITE, BLACK);
        printCards(player2);
    } else {
        cout << "Player 2's Cards: [Hidden]" << endl <<endl;
    }

    cout << endl;

   
    cout << "----------------------------------------" << endl <<endl;
    cout << "Top Card from the Deck:" << endl <<endl;
    printTopCard(topCard % 100, topCard / 100);
    cout << endl <<endl;
    cout << "----------------------------------------" << endl <<endl;

    cout << endl; // ( Go to Play Game function)
}

// Print Card (Called by Print Board)

int printCards(int playerCards[108]) {
    int bgColor, textColor;

    for (int i = 0; i < 108; i++) {
        if (playerCards[i] == -1) {
            continue; 
        }

        int color = playerCards[i] / 100;  
        int value = playerCards[i] % 100; 

        if (value == 13 || value == 14) { // Wild cards
            bgColor = WHITE;
            textColor = BLACK;
        } else {
           bgColor= assign_color (color);
            textColor = BLACK;
        }
        
        setColor(textColor, bgColor);
        cout << "+---------------+  ";
    }
     setColor(textColor, bgColor);
    cout << endl;

    for (int i = 0; i < 108; i++) {
        if (playerCards[i] == -1) {
            continue; 
        }

        int value = playerCards[i] % 100; 

        if (value == 13 || value == 14) { 
            bgColor = WHITE;
            textColor = BLACK;
        } else {
            int color = playerCards[i] / 100;
            
             bgColor= assign_color (color);
            textColor = BLACK;
        }

        setColor(textColor, bgColor);
        cout << "|               |  ";
    }
    cout << endl;

    for (int i = 0; i < 108; i++) {
        if (playerCards[i] == -1) {
            continue; 
        }

        int value = playerCards[i] % 100; 

        if (value == 13 || value == 14) { 
            bgColor = WHITE;
            textColor = BLACK;
        } else {
            int color = playerCards[i] / 100;
             bgColor= assign_color (color);
            textColor = BLACK;
        }

        setColor(textColor, bgColor);
        cout << "|";
        if (value >= 0 && value <= 9) {
            cout << "      " << value << "       ";
        } else if (value == 10) {
            cout << "   Reverse    ";
        } else if (value == 11) {
            cout << "    Skip      ";
        } else if (value == 12) {
            cout << "    Draw 2    ";
        } else if (value == 13) {
            cout << " Wild Card    ";
        } else if (value == 14) {
            cout << " Wild Draw 4  ";
        }
        cout << " |  ";
    }
    cout << endl;

    for (int i = 0; i < 108; i++) {
        if (playerCards[i] == -1) {
            continue; 
        }

        int value = playerCards[i] % 100; 

        if (value == 13 || value == 14) { 
            bgColor = WHITE;
            textColor = BLACK;
        } else {
            int color = playerCards[i] / 100;
            bgColor= assign_color (color);
            textColor = BLACK;
        }

        setColor(textColor, bgColor);
        cout << "|               |  ";
    }
    cout << endl;

    for (int i = 0; i < 108; i++) {
        if (playerCards[i] == -1) {
            continue; 
        }

        int value = playerCards[i] % 100; 
      
        if (value == 13 || value == 14) { 
            bgColor = WHITE;
            textColor = BLACK;
        } else {
            int color = playerCards[i] / 100;
             bgColor= assign_color (color);
            textColor = BLACK;
        }

        setColor(textColor, bgColor);
        cout << "+---------------+  ";
    }
    cout << endl;

    setColor(WHITE, BLACK); 
    return 0;
}

// Print Top Card (Called by Print Board)

int printTopCard(int cardValue, int color) 
 	{

 	int value = cardValue;
    int bgColor;
    if (cardValue == 13 || cardValue == 14){
     bgColor= assign_color (wildCard_color);                             
	}             
	else{
	
     bgColor= assign_color (color);
}
    setColor(BLACK, bgColor);

    cout << "+---------------+" << endl;
    cout << "|               |" << endl;

    if (cardValue >= 0 && cardValue <= 9) {
        cout << "|       " << cardValue << "       |" << endl; 
    } else if (cardValue == 10) {
        cout << "|    Reverse    |" << endl;
    } else if (cardValue == 11) {
        cout << "|     Skip      |" << endl;
    } else if (cardValue == 12) {
        cout << "|     Draw 2    |" << endl;
    } else if (cardValue == 13) {
      
        cout << "|   Wild Card   |" << endl;
    } else if (cardValue == 14) {
       
        cout << "|  Wild Draw 4  |" << endl;
        
    }   

    setColor(BLACK, bgColor); 
    cout << "|               |" << endl;
    cout << "+---------------+" << endl;
    setColor(WHITE, BLACK);  
	
    return cardValue; // (Go to printBoard function)
}

// Check the validity of the card

bool isValidPlay(int playerCard, int topCard) {
    int cardValue = playerCard % 100;
    int topValue = topCard % 100;

    if (cardValue == 13 || cardValue == 14) {
        return true;
    }

    if (topValue == 13 || topValue == 14) {
        return (playerCard / 100 == wildCard_color / 100);
    }

    return (playerCard / 100 == topCard / 100 || cardValue == topValue);
}

// Remove the cardis

void removePlayedCard(int playerCards[108], int cardIndex) {
    for (int i = cardIndex; i < 107; i++) {
        playerCards[i] = playerCards[i + 1];
    }

    playerCards[107] = -1;
}

// Handle Special Card

void handleSpecialCard(int specialCardType, int &topCard) {
    if (specialCardType == 10) { // Reverse
        setColor(WHITE, BLACK);
        cout << "Reverse card played! Turn order remains the same (one-on-one game)." << endl;
        // No change in currentPlayer for one-on-one game
    } else if (specialCardType == 11) { // Skip
        setColor(WHITE, BLACK);
        cout << "Skip card played! Skipping the next player's turn." << endl;
        currentPlayer = (currentPlayer == 1) ? 2 : 1;
    } else if (specialCardType == 12) { // Draw 2
        if (currentPlayer == 1) {
            setColor(WHITE, BLACK);
            cout << "Draw 2 card played! Player 2 must draw 2 cards." << endl;
            drawFromDeck(player2, 2);
            currentPlayer = 2;
        } else {
            setColor(WHITE, BLACK);
            cout << "Draw 2 card played! Player 1 must draw 2 cards." << endl;
            drawFromDeck(player1, 2);
            currentPlayer = 1;
        }
    } else if (specialCardType == 13) { // Wild
        setColor(WHITE, BLACK);
        cout << "Wild card played! Choose a color (1 = Red, 2 = Blue, 3 = Green, 4 = Yellow): ";
        int chosenColor;
        cin >> chosenColor;
        if (chosenColor < 1 || chosenColor > 4) {
            cout << "Invalid choice. Defaulting to Red." << endl;
            chosenColor = 1;
        }
        cout << "Color changed to ";
        switch (chosenColor) {
            case 1: cout << "Red"; wildCard_color = 100; break;
            case 2: cout << "Blue"; wildCard_color = 200; break;
            case 3: cout << "Green"; wildCard_color = 300; break;
            case 4: cout << "Yellow"; wildCard_color = 400; break;
        }
        cout << endl;
        topCard = wildCard_color + 13; // Update the top card to reflect the chosen color
    } else if (specialCardType == 14) { // Wild Draw 4
        setColor(WHITE, BLACK);
        cout << "Wild Draw 4 card played! The next player must draw 4 cards." << endl;
        cout << "Choose a color (1 = Red, 2 = Blue, 3 = Green, 4 = Yellow): ";
        int chosenColor;
        cin >> chosenColor;
        if (chosenColor < 1 || chosenColor > 4) {
            cout << "Invalid choice. Defaulting to Red." << endl;
            chosenColor = 1;
        }
        cout << "Color changed to ";
        switch (chosenColor) {
            case 1: cout << "Red"; wildCard_color = 100; break;
            case 2: cout << "Blue"; wildCard_color = 200; break;
            case 3: cout << "Green"; wildCard_color = 300; break;
            case 4: cout << "Yellow"; wildCard_color = 400; break;
        }
        cout << endl;
        topCard = wildCard_color + 14; // Update the top card to reflect the chosen color
        if (currentPlayer == 1) {
            drawFromDeck(player2, 4);
            currentPlayer = 2;
        } else {
            drawFromDeck(player1, 4);
            currentPlayer = 1;
        }
    }
}
// Draw from deck card

int drawFromDeck(int playerCards[108], int cardsToDraw) {
	int cardsDrawn = 0;
    for (int i = 0; i < 108 && cardsDrawn < cardsToDraw; i++) {
    	
        if (playerCards[i] == -1) {  
            int color, type;
            do {
                color = rand() % 10;  
                type = rand() % 15;   
            } while (deck[color][type] == -1); 

            playerCards[i] = deck[color][type];
            deck[color][type] = -1; 
            cardsDrawn++;
        }
    }
    
    return cardsDrawn; 
}


